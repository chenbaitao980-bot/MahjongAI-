#!/bin/bash
# MahjongAI Remote - ECS Deployment Script
# Upload to your Alibaba Cloud ECS and run as root/sudo

set -e

echo "=========================================="
echo "  MahjongAI Remote ECS Deployment"
echo "=========================================="
echo ""

INSTALL_DIR="/opt/mahjong-remote"

# 1. Install dependencies
echo "[1/5] Installing system dependencies..."
apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv

# 2. Create install directory
echo "[2/5] Creating $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp -r ./* "$INSTALL_DIR/"
cd "$INSTALL_DIR"

# 3. Install Python deps
echo "[3/5] Installing Python packages..."
pip3 install fastapi uvicorn pyyaml requests cryptography -q

# 4. Update config
echo "[4/5] Setting up config..."
API_TOKEN=$(python3 -c "import secrets; print(secrets.token_hex(12))")
cat > remote/relay/config.yaml << EOF
api_token: $API_TOKEN
game_server_ip: 47.96.0.227
game_server_port: 7777
handshake_blob: ''
auth_token_12b: ''
srs_sessionid: ''
push_timeout: 10
spectator_url: http://localhost:8001
EOF

cat > remote/extractor/config.yaml << EOF
relay_url: http://YOUR_ECS_PUBLIC_IP:8000
api_token: $API_TOKEN
game_port: 7777
EOF

echo "   RELEVANCE API_TOKEN: $API_TOKEN"
echo "   (save this — needed for extractor on your Windows machine)"

# 5. Create systemd services
echo "[5/5] Creating systemd services..."

cat > /etc/systemd/system/mahjong-relay.service << 'SERVICE'
[Unit]
Description=MahjongAI Relay Service
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/mahjong-remote
ExecStart=/usr/bin/python3 remote/relay/main.py --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

cat > /etc/systemd/system/mahjong-spectator.service << 'SERVICE'
[Unit]
Description=MahjongAI SRS Spectator Service
After=network.target mahjong-relay.service

[Service]
Type=simple
WorkingDirectory=/opt/mahjong-remote
ExecStart=/usr/bin/python3 remote/srs_spectator/main.py
Environment=RELAY_URL=http://127.0.0.1:8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable mahjong-relay mahjong-spectator
systemctl start mahjong-relay

echo ""
echo "=========================================="
echo "  Deployment Complete!"
echo "=========================================="
echo ""
echo "  Relay:  http://YOUR_ECS_PUBLIC_IP:8000"
echo "  API Token: $API_TOKEN"
echo ""
echo "  On your Windows machine, update remote/extractor/config.yaml:"
echo "    relay_url: http://YOUR_ECS_PUBLIC_IP:8000"
echo "    api_token: $API_TOKEN"
echo ""
echo "  Then run: python remote/extractor/main.py (as admin)"
echo ""
echo "  To check status:"
echo "    curl http://YOUR_ECS_PUBLIC_IP:8000/state?token=$API_TOKEN"
echo ""
